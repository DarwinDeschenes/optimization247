#ifndef MAT1_H
#define MAT1_H

long mat1_slow(matrix_t mat);
long mat1_fast(matrix_t mat);

#endif // MAT1_H
