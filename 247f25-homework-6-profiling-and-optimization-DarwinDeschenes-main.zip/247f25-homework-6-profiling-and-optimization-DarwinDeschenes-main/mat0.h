#ifndef MAT0_H
#define MAT0_H

long mat0_slow(matrix_t mat);
long mat0_fast(matrix_t mat);

#endif // MAT0_H
