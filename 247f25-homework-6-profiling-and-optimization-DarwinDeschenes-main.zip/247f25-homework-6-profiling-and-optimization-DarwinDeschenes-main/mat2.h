#ifndef MAT2_H
#define MAT2_H

long mat2_slow(matrix_t mat);
long mat2_fast(matrix_t mat);

#endif // MAT2_H
